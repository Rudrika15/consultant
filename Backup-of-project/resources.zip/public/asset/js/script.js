
var noPrint = true;
var noCopy = true;
var noScreenshot = true;
//var autoBlur=true;