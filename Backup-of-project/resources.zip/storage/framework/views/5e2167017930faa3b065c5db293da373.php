<div class="topcolor">
    <div class="container">
        <div class="d-flex justify-content-between flex-wrap p-3 gap-5">
            <div class="d-flex gap-1">
                <i class="fa fa-envelope pt-1"></i>
                <span>connect@consultantcube.com</span>
                <i class="fa fa-phone pt-1"></i>
                <span>7600891148</span>
            </div>
            <div class="d-flex toplinks gap-lg-3 gap-1">
                <div class="d-flex gap-3 login_links">
                    <i class="fa fa-facebook-f pt-lg-1"></i>
                    <i class="fa fa-instagram pt-lg-1"></i>
                    <i class="fa fa-linkedin pt-lg-1"></i>
                </div>
               
                <div class="d-flex gap-3 login_links">
                    <i class="fa fa-user-circle-o pt-1">
                        
                        <?php if(Auth::user()): ?>
                            <a href="<?php echo e(route('visitor.profile')); ?>" class="text-white"
                            style="text-decoration:none;"><?php echo e(Auth::user()->name); ?></a></i>        
                        <?php else: ?>
                            <a href="" data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="text-white"
                                style="text-decoration:none;">Login</a></i>
                                <i class="fa fa-plus pt-1"></i>
                            <a href="<?php echo e(route('register')); ?>" class="text-white" style="text-decoration:none;">Sign Up</a>
                                </i>
                        <?php endif; ?>    
                </div>
                <div class="d-flex gap-3 login_links">
                    <?php if(Auth::user()): ?>
                        <a class="dropdown-item" href="#"
                                onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out"></i>
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                style="display: none;">
                            <?php echo csrf_field(); ?>
                            </form>
                    <?php else: ?>
                        <i class="fa fa-plus pt-1"></i>
                        <a href="<?php echo e(route('register')); ?>" id="#becomecomsultanttype" style="text-decoration:none;color:white;">Become a Consultant</a>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Button trigger modal -->

  
  <!-- Modal -->
  <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog ">
      <div class="modal-content w-lg-75">
        <div class="modal-header" >
          <h5 class="modal-title" id="staticBackdropLabel">Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form class="user mt-5" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3 ">
                    <input type="email" placeholder="Email address" class="form-control p-3 form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" id="email" aria-describedby="emailHelp" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 mt-5">
                    <input type="password" name="password" placeholder="Password" class="form-control p-3 form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center mt-5">
                    <button type="button" class="btn " id="btn-secondary-close" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn" id="btn-primary-login" data-bs-dismiss="modal">Login</button>
                </div>
                    
            </form>
            <div class="mb-3 text-center mt-5">
                <?php if(Route::has('password.request')): ?>
                <a class="small bluetext" id="forgot-link" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                <?php endif; ?>
                <a class="small bluetext" id="create-new-account-link" href="<?php echo e(route('register')); ?>">Create New Account</a>

            </div>
        </div>
        
      </div>
    </div>
  </div><?php /**PATH D:\Laravel\consultant\consultant\resources\views/layouts/header.blade.php ENDPATH**/ ?>