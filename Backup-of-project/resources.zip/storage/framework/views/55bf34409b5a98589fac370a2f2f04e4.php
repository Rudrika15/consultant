<?php $__env->startSection('content'); ?>
<div class="main_page">
    <div class="membership">
        <h3 class="membertext ms-lg-5">Membership Plan</h3>
        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel" data-interval="500">
            <div class="carousel-inner">
                <?php $__currentLoopData = $sliderinner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item">
                        <img src="<?php echo e(url('/slider/'.$sliderinner->photo)); ?>" class="d-block w-100 img" height="300px" alt="...">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>
        </div>
    </div>
    <div class="grid pt-4">
        <div class="container">
            <a href="<?php echo e(route('visitors.index')); ?>" class="home_link">HOME</a>
            <span class="span_arrow">/</span>
            <a href="<?php echo e(route('visitors.membershipPlan')); ?>" class="membership_link">MEMBERSHIP PLAN</a>
        </div>
    </div>
    <div class="container mt-5 mb-5">
        <div class="row mb-5">
        <?php $__currentLoopData = $adminpackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminpackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 mt-2">
            <div class="card membercard shadow p-3 mb-5 bg-body rounded">
                <div class="card-body text-center">
                    <h3 class="card-title text-center" id="adminpackage-title"><?php echo e($adminpackage->title); ?><hr></h3>
                    <h4 class="card-title text-center" id="adminpackage-price">
                        <?php if($adminpackage->price>0): ?>
                            <i class='fa fa-rupee'></i><?php echo e($adminpackage->price); ?>

                        <?php else: ?>
                            <p>-</p>
                        <?php endif; ?>
                    </h4>
                    
                    <p class="card-text mt-5"><?php echo $adminpackage->details; ?></p>
                    
                    <?php if($adminpackage->title==="Free"): ?>
                        <a class="btn btn-primary mb-5 mt-5">Apply Now</a>
                       
                    <?php elseif(isset(Auth::user()->id)): ?>
                        
                        
                                <div class="card-body text-center">
                                    <form action="<?php echo e(route('razorpay.payment.store')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="package" value="<?php echo e($adminpackage->title); ?>">
                                        <script src="https://checkout.razorpay.com/v1/checkout.js"
                                                data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
                                                data-amount="<?php echo e($adminpackage->price * 100); ?>"
                                                data-buttontext="Apply Now"
                                                data-name="ConsultantCube.com"
                                                data-description="Rozerpay"
                                                data-image="<?php echo e(url('/visitors/images/ConsultantLogo.jpg')); ?>"
                                                data-prefill.name="name"
                                                
                                                data-theme.color="#333692">
                                        </script>
                                    </form>
                                </div>
                    <?php else: ?>
                        <a data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="btn btn-primary mb-5 mt-5">Apply Now</a> 
                    <?php endif; ?>
                        
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>
    </div>
    
    
    <div class="container allplan">
        <div class="text-center mt-5">
            <h1>All Plans Include</h1>
            <h5>Bring your people together under your brand on your terms !</h5>
        </div>
        <div class="row cardgap gap-lg-4 mt-lg-5 ms-lg-5 flex-wrap">
            <div class="col-md-2 card allplancard  shadow p-lg-3 mb-5 bg-gray rounded mt-5" id="allpanlcard-with">
                <div class="card-body text-center">
                    <a href="<?php echo e(route('visitor.profile')); ?>" style="text-decoration: none;color:black;">
                    <img  class="text-center profile-access-user-img" src="<?php echo e(asset('visitors/images/profile_access_user.png')); ?>">
                    <h5 class="card-text text-center">Profile Access</h5>
                    </a>
                </div>
            </div>
            <div class=" col-md-2 card allplancard shadow p-lg-3 mb-5 bg-gray rounded mt-lg-5" id="allpanlcard-with">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('visitors/images/windows_img.png')); ?>" alt="" class="category_img">
                    <h5 class="card-text text-center">Add Your Category</h5>
                </div>
            </div>
            <div class="col-md-2 card allplancard shadow p-3 mb-5 bg-body rounded mt-lg-5" id="allpanlcard-with">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('visitors/images/service_img.png')); ?>" alt="" class="service_img">
                    <h5 class="card-text text-center">Add Your Services</h5>
                </div>
            </div>
            <div class="col-md-2 card allplancard shadow p-3 mb-5 bg-body rounded mt-lg-5" id="allpanlcard-with">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('visitors/images/quotation_img.png')); ?>" alt="" class="quotation_img">
                    <h5 class="card-text text-center">Get Quotations
                    </h5>
                </div>
            </div>
            <div class="col-md-2 card allplancard shadow p-3 mb-5 bg-body rounded mt-lg-5" id="allpanlcard-with">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('visitors/images/cerificate_img.png')); ?>" alt="" class="certificate_img">
                    <h5 class="card-text text-center">Add Your Certificates</h5>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center">
            <a href="#" class="btn btn-primary text-center mt-lg-5 mb-lg-5">Apply Now</a>
        </div>
    </div>
    <div class="getstarted mt-5">
        <h1 class="text-center text-white pt-5">Get Started For Free</h1>
        <p class="text-center text-white pt-2">Our forever Free Plan is a great place to start, and you can upgrade to our
            Premium Plans
            whenever you’re ready
        </p>
        <div class="d-flex justify-content-center">
            <button class="btn bg-white text-center mt-4 mb-5">Start With Free</button>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#myCarousel').find('.carousel-item').first().addClass('active');
    });
</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.visitorApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/visitors/membershipPlan.blade.php ENDPATH**/ ?>