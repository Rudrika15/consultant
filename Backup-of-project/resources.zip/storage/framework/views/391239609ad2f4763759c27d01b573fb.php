<div class="container mt-5">
    <div class="row pt-3">
        <div class="col-4">
            <a href="<?php echo e(route('time.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Time</h5>
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($timecount); ?></h1>
                            </div>
                        </div> 
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('language.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Language</h5>
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($languagecount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('gallery.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Gallery</h5>                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($gallerycount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('video.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Video</h5>                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($videocount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('attachment.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Attachment</h5>                        </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($attachmentcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('socialLink.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8">
                                <h5 id="admin-card-heading" class="fw-bold">Social Link</h5>                        </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($socialcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('package.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Package</h5>                            
                                
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($packagecount); ?> </h1>
                            </div> 
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('certificate.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Certificate</h5>                               
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($certificatecount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('achievement.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Achivements</h5>                             
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($achievementcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('workshop.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Workshop</h5>                            
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($workshopcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('consultant.lead.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Leads</h5>                          
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($leadscount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
       
    </div>
</div>
<?php /**PATH D:\Laravel\consultant\consultant\resources\views/dashboard/consultant.blade.php ENDPATH**/ ?>