

<?php $__env->startSection('header','Upgrade Plan'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>



<div class="card">
    <!-- /.box-title -->
    <div class="card-header" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #345BCB; color:white;">
        <div class="">
            <h4 class="">Upgrade Plan</h4>
        </div>

    </div>
    <!-- /.dropdown js__dropdown -->
    
    <div class="card-body">
        <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mt-3" id="paymentplancard">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="card-text ms-0"><h3><?php echo e($data->title); ?></h3></div>
                        </div>
                        <div class="col-md-2">
                            <?php if($data->price>0): ?>
                                <div class="card-text"><h3><i class="fa fa-rupee "><?php echo e($data->price); ?></i></h3></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <?php if($data->title==="Free"): ?>
                            <Button style="display:none;"></Button>
                        <?php else: ?>
                        <div class="col-md-12 mt-2 mb-3">
                            <form action="<?php echo e(route('consultant.razorpay.payment.store')); ?>" method="POST" >
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="package" value="<?php echo e($data->title); ?>">
                                <script src="https://checkout.razorpay.com/v1/checkout.js"
                                        data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
                                        data-amount="<?php echo e($data->price * 100); ?>"
                                        data-buttontext="Pay Now"
                                        data-name="ConsultantCube.com"
                                        data-description="Rozerpay"
                                        data-image="<?php echo e(url('/visitors/images/ConsultantLogo.jpg')); ?>"
                                        data-prefill.name="name"
                                        data-theme.color="#345BCB"
                                        data-buttoncolor="#FF0000">
                                </script>
                            </form>
                        </div>
                        <?php endif; ?>
                        
                        <div class="col-md-8">
                            <div class="card-text"><?php echo $data->details; ?></div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/consultant/upgradeplan/index.blade.php ENDPATH**/ ?>