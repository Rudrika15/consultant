<?php $__env->startSection('header','Profile'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>



<div class="card">
    <!-- /.box-title -->
    <div class="card-header" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #345BCB; color:white;">

        <div class="">
            <h4 class="">Update Profile</h4>
        </div>

    </div>
    <!-- /.dropdown js__dropdown -->

    <div class="card-body">
        <form class="form-group" id="profileForm" name="profileForm" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="id" value="<?php echo e($profile->id); ?>">

            <div class="form-label-group mt-3">
                <label for="about" class="fw-bold">About</label>
                <textarea id="about" name="about" class="form-control"><?php echo $profile->about; ?></textarea>
                <?php if($errors->has('about')): ?>
                <span class="error"><?php echo e($errors->first('about')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="contactNo2" class="fw-bold">Mobile Number</label>
                <input id="contactNo2" type="text" name="contactNo2" class="form-control" placeholder="contactNo" value="<?php echo e($profile->contactNo2); ?>">
                <?php if($errors->has('contactNo2')): ?>
                <span class="error"><?php echo e($errors->first('contactNo2')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="skypeId" class="fw-bold">SkypeId</label>
                <input id="skypeId" type="text" name="skypeId" class="form-control" placeholder="skypeId" value="<?php echo e($profile->skypeId); ?>">
                <?php if($errors->has('skypeId')): ?>
                <span class="error"><?php echo e($errors->first('skypeId')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="webSite" class="fw-bold">Web Site</label>
                <input id="webSite" type="text" name="webSite" class="form-control" placeholder="webSite" value="<?php echo e($profile->webSite); ?>">
                <?php if($errors->has('webSite')): ?>
                <span class="error"><?php echo e($errors->first('webSite')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="map" class="fw-bold">Map</label>
                <input id="map" type="text" name="map" class="form-control" placeholder="map" value="<?php echo e($profile->map); ?>">
                <?php if($errors->has('map')): ?>
                <span class="error"><?php echo e($errors->first('map')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="address" class="fw-bold">Address</label>
                <textarea id="address" name="address" class="form-control"><?php echo $profile->address; ?></textarea>
                <?php if($errors->has('address')): ?>
                <span class="error"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">

                <div class="col-auto">
                    <label for="name" class="col-form-label text-md-end fw-bold"><?php echo e(__('State')); ?></label>

                    <select class="form-select" aria-label="Default select example" id="stateId" name="stateId" value="<?php echo e(old('stateId')); ?>" autocomplete="stateId" autofocus>
                        <option value="">-- select State --</option>
                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->stateName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['stateId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-auto">
                    <label for="name" class="col-form-label text-md-end fw-bold"><?php echo e(__('City')); ?></label>

                    <select class="form-select" aria-label="Default select example" id="cityId" name="cityId" value="<?php echo e(old('cityId')); ?>" autocomplete="cityId" autofocus>
                        <option value="">-- Select City --</option>

                    </select>
                    <?php $__errorArgs = ['cityId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


            <div class="form-label-group mt-3">
                <label for="pincode" class="fw-bold">Pin Code</label>
                <input id="pincode" type="text" name="pincode" class="form-control" placeholder="pincode" value="<?php echo e($profile->pincode); ?>">
                <?php if($errors->has('pincode')): ?>
                <span class="error"><?php echo e($errors->first('pincode')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <div class="row">
                    <div class="col-6">
                        <label for="photo" class="fw-bold">Photo</label>
                        <input id="photo" type="file" name="photo" class="form-control" placeholder="photo">
                        <?php if($errors->has('photo')): ?>
                        <span class="error"><?php echo e($errors->first('photo')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="col-6">

                        <img id="preview-photo" src="<?php echo e(asset('profile/' . $profile->photo)); ?>" alt="" width="70px" height="70px" class="img mt-3">
                    </div>
                </div>



            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mt-5 text-center">
                <button type="submit" id="saveBtn" class="btn btn-primary">Submit</button>
            </div>

        </form>
        <!-- </div> -->
    </div>
    <!-- Collapsable Card Example -->

</div>
<script src="https://cdn.ckeditor.com/ckeditor5/38.1.1/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#about'))
        .then(editor => {
            console.log(about);
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    ClassicEditor
        .create(document.querySelector('#address'))
        .then(editor => {
            // console.log(editor);
        })
        .catch(error => {
            console.error(error);
        });
</script>

<script>
    $(document).ready(function() {

        $('#stateId').on('change', function() {
            var idState = this.value;
            $("#cityId").html('');
            $.ajax({
                url: "<?php echo e(url('city')); ?>",
                type: "POST",
                data: {
                    stateId: idState,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(res) {
                    $('#cityId').html('<option value="">-- Select City --</option>');
                    $.each(res.cities, function(key, value) {
                        $("#cityId").append('<option value="' + value
                            .id + '">' + value.cityName + '</option>');
                    });
                }
            });

        });
    });
</script>

<!--  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/profile.blade.php ENDPATH**/ ?>