


<?php $__env->startSection('hePayment Get Way'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>



<div class="card">
    <!-- /.box-title -->
    <div class="card-header" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #345BCB; color:white;">

        <div class="">
            <h4 class="">Payment Get Way</h4>
        </div>
        <div class="">
            <a href="<?php echo e(route('upgradeplan.index')); ?>" class="btn btnback btn-sm">BACK</a>

            <!-- /.sub-menu -->
        </div>
    </div>
    <!-- /.dropdown js__dropdown -->

    <div class="card-body">
        <div class="card-body text-center">
            <form action="<?php echo e(route('consultant.razorpay.payment.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <input type="hidden" id="id" name="adminpackageid" value="<?php echo e($admin->id); ?>">
                <h3><?php echo e($admin->title); ?></h3>
                <h5><i class="fa fa-rupee"><?php echo e($admin->price); ?></i></h5>
                <?php echo $admin->details; ?></br>
                <script src="https://checkout.razorpay.com/v1/checkout.js"
                        data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
                        data-amount="<?php echo e($admin->price * 100); ?>"
                        data-buttontext="Pay Now"
                        data-name="ConsultantCube.com"
                        data-description="Rozerpay"
                        data-image="<?php echo e(url('/visitors/images/ConsultantLogo.jpg')); ?>"
                        data-prefill.name="name"
                        data-theme.color="#333692"
                        data-button.backgroundcolor="#333692">
                </script>
                
            </form>
        </div>
        <!-- </div> -->
    </div>
    <!-- Collapsable Card Example -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/consultant/upgradeplan/paymentpage.blade.php ENDPATH**/ ?>