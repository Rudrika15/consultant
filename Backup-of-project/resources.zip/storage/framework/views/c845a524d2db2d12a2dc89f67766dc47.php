<?php $__env->startSection('content'); ?>
<div class="main_page">
    <div class="about">
        <h3 class="us ms-lg-5">About us</h3>
        
        
            <div id="myCarousel" class="carousel slide" data-bs-ride="carousel" data-interval="500">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $sliderinner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <img src="<?php echo e(url('/slider/'.$sliderinner->photo)); ?>" class="d-block w-100 img" height="300px" alt="...">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>
            </div>
    </div>
    <div class="grid pt-4">
        <div class="container">
            <a href="<?php echo e(route('visitors.index')); ?>" class="home_link">HOME</a>
            <span class="span_arrow">/</span>
            <a href="<?php echo e(route('visitors.aboutus')); ?>" class="about_us_link">ABOUT US</a>
        </div>
    </div>
    <div class="container mt-5 p-5">
        <div class="ms-lg-5 me-lg-5">
            <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="pcolor"><?php echo $aboutData->about; ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                $(document).ready(function () {
                    $('#myCarousel').find('.carousel-item').first().addClass('active');
                });
            </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.visitorApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/visitors/aboutus.blade.php ENDPATH**/ ?>