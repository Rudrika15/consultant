<div class="container mt-5">
    <div class="row pt-3">
        <div class="col-4">
            <a href="<?php echo e(route('consultant.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Consultant</h5>
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($consultantcount); ?></h1>
                            </div>
                        </div> 
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('state.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">State</h5>
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($statecount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('city.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">City</h5>                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($citycount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('category.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Category</h5>                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($categorycount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('languageMaster.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Language Master</h5>                        </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($languagecount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('socialMaster.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8">
                                <h5 id="admin-card-heading" class="fw-bold">Social Media Master</h5>                        </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($socialmastercount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('adminpackage.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Admin Package</h5>                            
                                
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($adminpackagecount); ?> </h1>
                            </div> 
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('corparateInquiry.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Inquiry</h5>                               
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($inquirycount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('adminworkshop.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Workshop</h5>                             
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($workshopcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('slider.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Slider</h5>                            
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($slidercount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('admin.lead.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Leads</h5>                          
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($leadscount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        
        <div class="col-4">
            <a href="<?php echo e(route('about.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">About</h5>                          
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($aboutcount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
        <div class="col-4">
            <a href="<?php echo e(route('pincode.index')); ?>" id="admin-dashborad-card-link">
                <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8 mt-3">
                                <h5 id="admin-card-heading" class="fw-bold">Pincode</h5>                          
                            </div>
                            <div class="col-4">
                                <h1 class="fw-bold"><?php echo e($pincodecount); ?> </h1>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </a>
        </div>
    <div class="col-4">
        <a href="<?php echo e(route('contactus.index')); ?>" id="admin-dashborad-card-link">
            <div class="card shadow p-3 mb-5 bg-white rounded" id="Admin-dashborad-card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-8 mt-3">
                            <h5 id="admin-card-heading" class="fw-bold">Contactus</h5>                         
                        </div>
                        <div class="col-4">
                            <h1 class="fw-bold"><?php echo e($contactuscount); ?> </h1>
                        </div>
                    </div>
                
                </div>
            </div>
        </a>
    </div>
    </div>
</div>
<?php /**PATH D:\Laravel\consultant\consultant\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>