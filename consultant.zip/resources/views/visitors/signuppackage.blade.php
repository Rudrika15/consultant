@extends('layouts.visitorApp')
@section('content')
    <div class="main_page">
        <h1>Sign up Package</h1>
    </div>
@endsection