-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2023 at 08:08 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `consultant-cube`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `about` longtext NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `about`, `status`, `created_at`, `updated_at`) VALUES
(1, '<p>Nothing but change is constant! In this constantly changing world, GROWTH is inevitable for everyone. From one who is already successful to one starting just now. Each of us needs a guiding factor in form of a mentor, coach, or a CONSULTANT.</p><p>Consultant Cube provides the much-needed platform where individuals, businesses, start-ups, giants, or consultants themselves can have easy access to finding their respective Consultants from various domains.</p><p>Our simple yet appealing global platform lets the clients connect with the respective Consultants and meet their precise requirements in their own cube.</p>', 'Active', '2023-09-04 04:55:21', '2023-09-04 04:59:02');

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

CREATE TABLE `achievements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `userId`, `title`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'Achievement 1', '1690444021.jpg', 'Active', '2023-07-27 02:17:01', '2023-07-27 02:17:01'),
(2, 14, 'Achievement 2', '1690444045.jpg', 'Deleted', '2023-07-27 02:17:25', '2023-07-27 02:17:52'),
(3, 11, 'Achivment 3', '1690444116.jpg', 'Deleted', '2023-07-27 02:18:36', '2023-07-29 03:40:20'),
(4, 14, 'Api', '1690536641.jpg', 'Active', '2023-07-28 01:39:34', '2023-07-28 06:04:23'),
(5, 12, 'Achivement api 2', '1690531537.jpg', 'Active', '2023-07-28 02:35:37', '2023-07-28 02:35:37'),
(6, 14, 'Achivement api 2', '1690531608.jpg', 'Deleted', '2023-07-28 02:36:48', '2023-07-28 03:37:54'),
(7, 14, 'Achivement api 2', '1690536662.jpg', 'Active', '2023-07-28 04:01:03', '2023-07-28 04:01:03');

-- --------------------------------------------------------

--
-- Table structure for table `admin_packages`
--

CREATE TABLE `admin_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `details` longtext NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_packages`
--

INSERT INTO `admin_packages` (`id`, `title`, `price`, `details`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Free', 0, '<ul><li>Profile Name</li><li>Photo</li><li>Coaching/Category</li><li>Add Your Services</li><li>Maximum 5 Quotations</li><li>Full profile</li><li>Certificate update</li></ul>', 'Active', '2023-08-23 01:27:50', '2023-08-26 00:27:40'),
(2, 'Silver', 500, '<ul><li>Profile Name</li><li>Consulting Call Booking (Per Booking 10% Administration Fee)</li><li>Coaching/Category</li><li>Full Profile Page</li><li>video on profile page</li><li>Upload of certificates &amp; awards</li></ul>', 'Active', '2023-08-23 01:30:07', '2023-08-26 00:27:26'),
(3, 'Gold', 1000, '<ul><li>Consulting Call Booking &nbsp;(Per Booking 5% Administration Fee)</li><li>Coaching/Category</li><li>Full Profile Page</li><li>video on profile page</li><li>Upload of certificates &amp; awards</li><li>Part of Elite Networking community</li><li>Show as Featured coach on home page &amp; other relevant pages</li><li>Determine Your Services</li><li>Feature in Promotion &amp; Publicity Campaign on social media and other platforms</li><li>Publish unlimited events/news</li><li>Publish unlimited Article/Blogs<br>&nbsp;</li></ul>', 'Active', '2023-08-23 04:18:45', '2023-08-26 00:29:48');

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `userId`, `title`, `file`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'Attachment 1', '1690356466.jpg', 'Deleted', '2023-07-21 07:01:23', '2023-07-27 01:02:31'),
(2, 10, 'Attachment 2', '1689943333.jpg', 'Deleted', '2023-07-21 07:09:48', '2023-07-24 06:28:32'),
(3, 14, 'Attachment 3', '1690355923.jpg', 'Deleted', '2023-07-21 07:11:33', '2023-07-26 06:07:13'),
(4, 14, 'Attachment', '1690350350.jpg', 'Deleted', '2023-07-25 06:22:36', '2023-07-26 00:19:06'),
(5, 14, 'attachment 4', '1690350162.jpg', 'Deleted', '2023-07-26 00:12:42', '2023-07-26 00:19:32'),
(6, 14, 'attachment 5', '1690350212.jpg', 'Deleted', '2023-07-26 00:13:32', '2023-07-26 00:19:24'),
(7, 14, 'Aaaaaaa', '1690355817.jpg', 'Deleted', '2023-07-26 01:46:57', '2023-07-26 05:21:56'),
(8, 14, 'Attachment 2', '1690371383.jpg', 'Deleted', '2023-07-26 06:06:23', '2023-07-27 00:51:50'),
(9, 14, 'aaaaaaaa', '1690372690.jpg', 'Active', '2023-07-26 06:28:10', '2023-07-26 06:28:10'),
(10, 14, 'Attach Update Api', '1690622476.png', 'Active', '2023-07-26 06:32:35', '2023-07-29 03:51:16'),
(11, 14, 'Attach Api 1', '1690532462.jpg', 'Deleted', '2023-07-28 02:51:02', '2023-07-28 03:35:54'),
(12, 14, 'List of Consultants', '1690622409.png', 'Active', '2023-07-29 03:50:09', '2023-07-29 03:50:09');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `catName` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `catName`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Yoga Coach', '1692359156.jpg', 'Active', '2023-08-11 06:42:16', '2023-08-18 06:15:56'),
(2, 'Career Transition', '1692359126.jpg', 'Active', '2023-08-11 06:42:40', '2023-08-18 06:15:26'),
(3, 'Content Writing', '1692359099.jpg', 'Active', '2023-08-11 06:42:50', '2023-08-18 06:14:59'),
(4, 'Image Consultant', '1692359075.jpg', 'Active', '2023-08-11 06:43:02', '2023-08-18 06:14:35'),
(5, 'Education', '1692359043.jpg', 'Active', '2023-08-11 06:43:11', '2023-08-18 06:14:03'),
(6, 'Ditetician', '1692359011.jpg', 'Active', '2023-08-11 06:45:15', '2023-08-18 06:13:31'),
(7, 'Chess Coach', '1692358979.jpg', 'Active', '2023-08-11 06:45:29', '2023-08-18 06:12:59'),
(8, 'Branding', '1692358948.jpg', 'Active', '2023-08-11 06:45:59', '2023-08-18 06:12:28'),
(9, 'Agile Coach', '1692358178.jpg', 'Active', '2023-08-11 06:46:14', '2023-08-18 05:59:38'),
(10, 'Executive', '1692358155.jpg', 'Active', '2023-08-11 06:46:25', '2023-08-18 05:59:15'),
(11, 'Meditation', '1692358121.webp', 'Active', '2023-08-11 06:46:34', '2023-08-18 05:58:41'),
(12, 'Soft Skill Trainer', '1692358090.avif', 'Active', '2023-08-11 06:47:23', '2023-08-18 05:58:10'),
(14, 'Mindset', '1692358061.jpg', 'Active', '2023-08-11 06:47:34', '2023-08-18 05:57:41'),
(15, 'Performance', '1692358034.jpg', 'Active', '2023-08-11 06:47:51', '2023-08-18 05:57:14'),
(16, 'Relationship', '1692358002.jpg', 'Active', '2023-08-11 06:48:04', '2023-08-18 05:56:42'),
(17, 'Wellness', '1692357731.jpg', 'Active', '2023-08-11 06:48:10', '2023-08-18 05:52:11'),
(18, 'Higher Studies', '1692357706.webp', 'Active', '2023-08-11 06:48:26', '2023-08-18 05:51:46'),
(19, 'Sales', '1692357680.jpg', 'Active', '2023-08-11 06:48:44', '2023-08-18 05:51:20'),
(20, 'Language Consultant', '1692357606.jpg', 'Active', '2023-08-11 06:48:52', '2023-08-18 05:50:06'),
(21, 'Marketing', '1692357579.jpg', 'Active', '2023-08-11 06:49:04', '2023-08-18 05:49:40'),
(23, 'Life Coach', '1692357541.png', 'Active', '2023-08-11 06:49:12', '2023-08-18 05:49:01'),
(24, 'Career', '1692357515.jpg', 'Active', '2023-08-11 06:49:23', '2023-08-18 05:48:35'),
(25, 'Business Coach', '1692356376.jpg', 'Active', '2023-08-11 06:49:35', '2023-08-18 05:29:36'),
(26, 'Happiness', '1692356352.jpg', 'Active', '2023-08-11 06:49:45', '2023-08-18 05:29:12'),
(27, 'Life Style', '1692356318.png', 'Active', '2023-08-11 06:49:55', '2023-08-18 05:28:38'),
(28, 'Holistic Healer', '1692356294.webp', 'Active', '2023-08-11 06:50:22', '2023-08-18 05:28:14'),
(29, 'Retirement', '1692356270.avif', 'Active', '2023-08-11 06:50:40', '2023-08-18 05:27:50'),
(30, 'Vision', '1692356243.jpg', 'Active', '2023-08-11 06:50:49', '2023-08-18 05:27:23'),
(31, 'Technical', '1692356223.jpg', 'Active', '2023-08-11 06:51:09', '2023-08-18 05:27:03'),
(32, 'Finance', '1692356199.avif', 'Active', '2023-08-11 06:51:18', '2023-08-18 05:26:39'),
(33, 'Self Mastery', '1692356174.webp', 'Active', '2023-08-11 06:51:24', '2023-08-18 05:26:14'),
(34, 'Fitness', '1692355473.jpg', 'Active', '2023-08-11 06:51:34', '2023-08-18 05:14:33'),
(35, 'Transformation', '1692355457.jpg', 'Active', '2023-08-11 06:51:41', '2023-08-18 05:14:17'),
(36, 'Leadership', '1692355443.webp', 'Active', '2023-08-11 06:51:53', '2023-08-18 05:14:03'),
(37, 'Legal Consultant', '1692355427.avif', 'Active', '2023-08-11 06:52:08', '2023-08-18 05:13:47'),
(38, 'Last One', '1692354712.png', 'Deleted', '2023-08-18 04:27:47', '2023-08-18 05:07:32');

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`id`, `userId`, `title`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'certificate 0', '1690442801.jpg', 'Deleted', '2023-07-27 01:56:41', '2023-07-27 02:03:23'),
(2, 14, 'Certificate 1', '1690442919.jpg', 'Active', '2023-07-27 01:58:39', '2023-07-27 01:58:39'),
(3, 14, 'Certificate 2', '1690442955.jpg', 'Active', '2023-07-27 01:59:15', '2023-07-27 02:05:07'),
(4, 14, 'Certificate Update Api', '1690536865.jpg', 'Active', '2023-07-28 03:08:36', '2023-07-28 04:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stateId` int(11) NOT NULL,
  `cityName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `stateId`, `cityName`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ahmedabad', 'Deleted', '2023-08-11 06:56:36', '2023-09-03 23:57:55'),
(2, 1, 'Amreli', 'Deleted', '2023-08-11 06:56:47', '2023-09-03 23:57:43'),
(3, 1, 'Anand', 'Deleted', '2023-08-11 06:57:04', '2023-09-03 23:57:30'),
(4, 1, 'Anand', 'Active', '2023-08-11 06:57:05', '2023-08-11 06:57:05'),
(5, 1, 'Aravalli', 'Active', '2023-08-11 06:57:19', '2023-08-11 06:57:19'),
(6, 1, 'Banaskantha', 'Active', '2023-08-11 06:57:35', '2023-08-11 06:57:35'),
(7, 1, 'Bharuch', 'Active', '2023-08-11 06:57:45', '2023-08-11 06:57:45'),
(8, 1, 'Bhavnagar', 'Active', '2023-08-11 06:57:55', '2023-08-11 06:57:55'),
(9, 1, 'Bhavnagar', 'Active', '2023-08-11 06:57:55', '2023-08-11 06:57:55'),
(10, 1, 'Botad', 'Active', '2023-08-11 06:58:10', '2023-08-11 06:58:10'),
(11, 1, 'Chhota Udaipur', 'Active', '2023-08-11 06:58:33', '2023-08-11 06:58:33'),
(12, 1, 'Dahod', 'Active', '2023-08-11 06:58:46', '2023-08-11 06:58:46'),
(13, 1, 'Dang', 'Active', '2023-08-11 06:59:03', '2023-08-11 06:59:03'),
(14, 1, 'Devbhoomi Dwarka', 'Active', '2023-08-11 06:59:13', '2023-08-11 06:59:13'),
(15, 1, 'Gandhinagar', 'Active', '2023-08-11 06:59:22', '2023-08-11 06:59:22'),
(16, 1, 'Gandhinagar', 'Active', '2023-08-11 06:59:22', '2023-08-11 06:59:22'),
(17, 1, 'Gir Somnath', 'Active', '2023-08-11 06:59:33', '2023-08-11 06:59:33'),
(18, 1, 'Jamnagar', 'Active', '2023-08-11 06:59:44', '2023-08-11 06:59:44'),
(19, 1, 'Junagadh', 'Active', '2023-08-11 07:00:01', '2023-08-11 07:00:01'),
(20, 1, 'Kutch', 'Active', '2023-08-11 07:00:21', '2023-08-11 07:00:21'),
(21, 1, 'Kheda', 'Active', '2023-08-11 07:00:36', '2023-08-11 07:00:36'),
(22, 1, 'Mahisagar', 'Active', '2023-08-11 07:00:47', '2023-08-11 07:00:47'),
(23, 1, 'Mehsana', 'Active', '2023-08-11 07:01:05', '2023-08-11 07:01:05'),
(24, 1, 'Morbi', 'Active', '2023-08-11 07:01:29', '2023-08-11 07:01:29'),
(25, 1, 'Narmada', 'Active', '2023-08-11 07:01:39', '2023-08-11 07:01:39'),
(26, 1, 'Navsari', 'Active', '2023-08-11 07:01:49', '2023-08-11 07:01:49'),
(27, 1, 'Panchmahal', 'Active', '2023-08-11 07:02:26', '2023-08-11 07:02:26'),
(28, 1, 'Patan', 'Active', '2023-08-11 07:02:44', '2023-08-11 07:02:44'),
(29, 1, 'Porbandar', 'Active', '2023-08-11 07:02:54', '2023-08-11 07:02:54'),
(30, 1, 'Rajkot', 'Active', '2023-08-11 07:03:04', '2023-08-11 07:03:04'),
(31, 1, 'Sabarkantha', 'Active', '2023-08-11 07:03:16', '2023-08-11 07:03:16'),
(32, 1, 'Surat', 'Active', '2023-08-11 07:03:30', '2023-08-11 07:03:30'),
(33, 1, 'Surendranagar', 'Active', '2023-08-11 07:03:42', '2023-08-11 07:03:42'),
(34, 1, 'Tapi', 'Active', '2023-08-11 07:04:04', '2023-08-11 07:04:04'),
(35, 1, 'Vadodara', 'Active', '2023-08-11 07:04:16', '2023-08-11 07:04:16'),
(36, 1, 'Valsad', 'Active', '2023-08-11 07:04:25', '2023-08-11 07:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `contactuses`
--

CREATE TABLE `contactuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contactuses`
--

INSERT INTO `contactuses` (`id`, `name`, `email`, `phone`, `comments`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Manisha H. Parmar', 'manisha@gmail.com', '8469678866', 'This is the testing', 'Active', '2023-09-04 03:45:17', '2023-09-04 03:45:17'),
(2, 'Lata H. Parmar', 'lata@gmail.com', '8866222922', 'This is the lata\'s testing', 'Active', '2023-09-04 03:47:13', '2023-09-04 03:47:13'),
(3, 'Theory', 'theory@gmail.com', '9408666701', 'Comments', 'Active', '2023-09-04 04:29:31', '2023-09-04 04:29:31');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `userId`, `title`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 10, 'Customer Service', '1690623248.webp', 'Active', '2023-07-21 06:15:23', '2023-07-29 04:04:08'),
(2, 14, 'Gallery', '1690363312.jpg', 'Deleted', '2023-07-21 06:23:19', '2023-07-26 05:18:58'),
(3, 14, 'Gallery', '1690355285.jpg', 'Active', '2023-07-25 06:16:54', '2023-07-26 01:38:05'),
(4, 14, 'Gallery', '1690355304.jpg', 'Deleted', '2023-07-25 08:17:05', '2023-07-27 00:51:34'),
(5, 14, 'Gallery', '1690355679.jpg', 'Active', '2023-07-25 08:17:50', '2023-07-26 01:44:39'),
(6, 14, 'Gallery', '1690349825.jpg', 'Active', '2023-07-25 08:22:35', '2023-07-26 00:07:05'),
(7, 14, 'Gallery 5', '1690349848.jpg', 'Deleted', '2023-07-25 23:41:36', '2023-07-26 00:22:33'),
(8, 14, 'Gallery new', '1690354646.jpg', 'Active', '2023-07-26 01:27:27', '2023-07-26 01:27:27'),
(9, 14, 'Gallery New one', '1690372525.jpg', 'Active', '2023-07-26 01:28:58', '2023-07-26 06:25:25'),
(10, 14, 'Gallery New oneeeee', '1690354935.jpg', 'Active', '2023-07-26 01:32:15', '2023-07-26 01:32:15'),
(11, 14, 'zzzxzxz', '1690355044.jpg', 'Deleted', '2023-07-26 01:34:04', '2023-07-26 06:09:10'),
(12, 14, 'vcxvcxvcx', '1690355094.jpg', 'Deleted', '2023-07-26 01:34:54', '2023-07-26 06:09:06'),
(13, 14, 'aaaaaa', '1690372442.jpg', 'Active', '2023-07-26 06:24:02', '2023-07-26 06:24:02'),
(14, 14, 'vbvbvb', '1690453835.jpg', 'Active', '2023-07-27 01:57:36', '2023-07-27 05:00:35'),
(15, 14, 'sdfsfdsfsd', '1690453851.jpg', 'Active', '2023-07-27 02:00:37', '2023-07-27 05:00:51'),
(16, 14, 'aaaaa', '1690453328.jpg', 'Deleted', '2023-07-27 04:52:08', '2023-07-27 05:44:23'),
(17, 14, 'bbbbbbb', '1690453340.jpg', 'Active', '2023-07-27 04:52:20', '2023-07-27 04:52:20'),
(18, 14, 'ccccccc', '1690453356.jpg', 'Active', '2023-07-27 04:52:36', '2023-07-27 04:52:36'),
(19, 14, 'Gallery Update Api', '1690536977.jpg', 'Active', '2023-07-28 03:22:58', '2023-07-28 04:06:17'),
(20, 14, 'Gallery Store', '1690534520.jpg', 'Active', '2023-07-28 03:25:20', '2023-07-28 03:25:20'),
(21, 14, 'Customer service', '1690623197.webp', 'Active', '2023-07-29 04:03:17', '2023-07-29 04:03:17');

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `inquiry` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inquiries`
--

INSERT INTO `inquiries` (`id`, `name`, `email`, `inquiry`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Manisha H. Parmar', 'manisha@gmail.com', '<p>Inquiry</p>', 'Active', '2023-08-22 01:35:26', '2023-08-22 01:35:26'),
(2, 'Lata H. Jadav', 'lata@gmail.com', '<p>Education Inquiery</p>', 'Active', '2023-08-22 01:37:29', '2023-08-22 01:37:29'),
(3, 'Bhavin Vaghela', 'bhavin@gmail.com', '<p>Yoga Inquiry</p>', 'Active', '2023-08-22 01:42:40', '2023-08-22 01:42:40'),
(4, 'Rahul', 'rahul@gmail.com', '<p>Education Inquiry</p>', 'Active', '2023-08-22 01:43:32', '2023-08-22 01:43:32'),
(5, 'Bhavin D. Vaghela', 'bhavin@gmail.com', '<p>Consultant Inquiry</p>', 'Active', '2023-08-26 01:34:00', '2023-08-26 01:34:00'),
(6, 'Bhavin D. Vaghela', 'bhavin@gmail.com', '<p>Latest Inquiry</p>', 'Active', '2023-09-01 23:44:46', '2023-09-01 23:44:46');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `languageId` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `userId`, `languageId`, `status`, `created_at`, `updated_at`) VALUES
(24, 14, 2, 'Active', '2023-07-29 01:52:16', '2023-07-29 01:52:16'),
(25, 14, 3, 'Active', '2023-08-14 05:45:05', '2023-08-14 05:45:05');

-- --------------------------------------------------------

--
-- Table structure for table `language_masters`
--

CREATE TABLE `language_masters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `language` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `language_masters`
--

INSERT INTO `language_masters` (`id`, `language`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Hindi', 'Deleted', '2023-07-21 03:55:56', '2023-07-24 06:16:50'),
(2, 'English', 'Active', '2023-07-21 05:57:51', '2023-07-21 05:57:51'),
(3, 'Bagoli', 'Active', '2023-07-21 05:58:09', '2023-08-12 03:31:30'),
(5, 'Telugu', 'Active', '2023-08-12 03:29:03', '2023-08-12 03:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `userId`, `categoryId`, `status`, `created_at`, `updated_at`) VALUES
(1, 44, 5, 'Active', '2023-09-01 01:44:50', '2023-09-01 01:44:50'),
(2, 44, 5, 'Active', '2023-09-01 01:45:28', '2023-09-01 01:45:28'),
(3, 44, 5, 'Active', '2023-09-01 03:35:37', '2023-09-01 03:35:37'),
(4, 43, 6, 'Active', '2023-09-01 03:36:42', '2023-09-01 03:36:42'),
(5, 43, 6, 'Active', '2023-09-01 03:40:35', '2023-09-01 03:40:35'),
(6, 44, 1, 'Active', '2023-09-01 07:37:58', '2023-09-01 07:37:58'),
(7, 44, 6, 'Active', '2023-09-01 07:41:08', '2023-09-01 07:41:08'),
(8, 44, 8, 'Active', '2023-09-01 08:38:29', '2023-09-01 08:38:29'),
(9, 44, 23, 'Active', '2023-09-01 08:38:44', '2023-09-01 08:38:44'),
(31, 44, 1, 'Active', '2023-09-01 23:24:44', '2023-09-01 23:24:44'),
(32, 44, 1, 'Active', '2023-09-01 23:28:03', '2023-09-01 23:28:03'),
(33, 44, 5, 'Active', '2023-09-01 23:32:32', '2023-09-01 23:32:32'),
(34, 44, 8, 'Active', '2023-09-01 23:34:41', '2023-09-01 23:34:41'),
(35, 44, 8, 'Active', '2023-09-01 23:36:29', '2023-09-01 23:36:29'),
(36, 44, 5, 'Active', '2023-09-01 23:36:57', '2023-09-01 23:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(3, '2014_10_12_000000_create_users_table', 2),
(4, '2014_10_12_100000_create_password_reset_tokens_table', 2),
(5, '2019_08_19_000000_create_failed_jobs_table', 2),
(6, '2023_07_20_091531_create_permission_tables', 2),
(7, '2023_07_20_091601_create_products_table', 2),
(8, '2023_07_21_061718_create_states_table', 3),
(9, '2023_07_21_071434_create_cities_table', 4),
(10, '2023_07_21_071459_create_categories_table', 4),
(11, '2023_07_21_071528_create_language_masters_table', 4),
(12, '2023_07_21_071609_create_social_masters_table', 4),
(13, '2023_07_21_072957_create_times_table', 5),
(14, '2023_07_21_073011_create_profiles_table', 5),
(15, '2023_07_21_073049_create_languages_table', 5),
(16, '2023_07_21_073158_create_galleries_table', 5),
(18, '2023_07_21_073657_create_videos_table', 5),
(19, '2023_07_21_075728_create_social_links_table', 6),
(20, '2023_07_21_121558_create_attachments_table', 7),
(21, '2023_07_26_121740_create_packages_table', 8),
(22, '2023_07_26_122000_create_certificates_table', 9),
(23, '2023_07_26_122313_create_achievements_table', 10),
(24, '2023_07_31_214900_create_inquiries_table', 11),
(25, '2023_08_23_061511_create_admin_packages_table', 12),
(26, '2023_08_24_091656_create_workshops_table', 13),
(28, '2023_08_25_122106_create_sliders_table', 14),
(31, '2023_08_29_114437_create_payments_table', 15),
(32, '2023_09_01_062911_create_leads_table', 16),
(33, '2023_09_04_070919_create_contactuses_table', 17),
(34, '2023_09_04_100327_create_abouts_table', 18);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 7),
(2, 'App\\Models\\User', 8),
(2, 'App\\Models\\User', 9),
(2, 'App\\Models\\User', 10),
(2, 'App\\Models\\User', 11),
(2, 'App\\Models\\User', 12),
(2, 'App\\Models\\User', 13),
(2, 'App\\Models\\User', 14),
(2, 'App\\Models\\User', 15),
(2, 'App\\Models\\User', 16),
(2, 'App\\Models\\User', 17),
(2, 'App\\Models\\User', 18),
(2, 'App\\Models\\User', 19),
(2, 'App\\Models\\User', 20),
(2, 'App\\Models\\User', 21),
(2, 'App\\Models\\User', 22),
(2, 'App\\Models\\User', 23),
(2, 'App\\Models\\User', 24),
(2, 'App\\Models\\User', 25),
(2, 'App\\Models\\User', 26),
(2, 'App\\Models\\User', 27),
(2, 'App\\Models\\User', 28),
(2, 'App\\Models\\User', 29),
(2, 'App\\Models\\User', 30),
(2, 'App\\Models\\User', 31),
(2, 'App\\Models\\User', 32),
(2, 'App\\Models\\User', 33),
(2, 'App\\Models\\User', 34),
(2, 'App\\Models\\User', 35),
(2, 'App\\Models\\User', 36),
(2, 'App\\Models\\User', 37),
(2, 'App\\Models\\User', 38),
(2, 'App\\Models\\User', 39),
(2, 'App\\Models\\User', 40),
(2, 'App\\Models\\User', 41),
(3, 'App\\Models\\User', 43),
(3, 'App\\Models\\User', 44);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `validUpTo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `userId`, `title`, `price`, `detail`, `validUpTo`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'free', '100', 'Package', '2 Month', 'Deleted', '2023-07-26 07:29:49', '2023-07-27 00:52:57'),
(2, 14, 'sliver', '100', 'Package 1', '1 Momth', 'Active', '2023-07-26 07:36:30', '2023-07-26 08:05:16'),
(3, 14, 'golde', '200', 'Package 3', '3 Months', 'Deleted', '2023-07-26 08:55:42', '2023-07-27 00:52:39'),
(4, 14, 'platinum', '1000', 'Package Update Api', '6 Months', 'Active', '2023-07-27 06:48:57', '2023-07-28 06:07:56');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('madhavipalte202203@gmail.com', '$2y$10$M0FKUHby7y86yXZKeApLceanM60KWAvX5EvmGU/ZOpoMDGJmJc156', '2023-07-22 04:34:04'),
('madhvi@gmail.com', '$2y$10$cXfXZyPTMzN/xNGsWglcAed0o40v6v6pMuvWvSVsvHliEd5RMrPMa', '2023-07-22 04:33:10');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `r_payment_id` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `package` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `json_response` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `r_payment_id`, `userId`, `method`, `currency`, `user_email`, `package`, `amount`, `json_response`, `created_at`, `updated_at`) VALUES
(1, 'pay_MVsHLiwiugahU4', 0, 'netbanking', 'INR', 'abc@gmail.com', '', '100', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVsHLiwiugahU4\",\"entity\":\"payment\",\"amount\":10000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Razorpay payment\",\"card_id\":null,\"bank\":\"BARB_R\",\"wallet\":null,\"vpa\":null,\"email\":\"abc@gmail.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":236,\"tax\":36,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693310000}}', '2023-08-29 06:23:33', '2023-08-29 06:23:33'),
(2, 'pay_MVsTBSt23FeDCt', 0, 'netbanking', 'INR', 'void@razorpay.com', '', '10', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVsTBSt23FeDCt\",\"entity\":\"payment\",\"amount\":1000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":null,\"bank\":\"IBKL\",\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":24,\"tax\":4,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693310672}}', '2023-08-29 06:34:46', '2023-08-29 06:34:46'),
(3, 'pay_MVsVHMRIqhAH6w', 0, 'card', 'INR', 'void@razorpay.com', '', '10', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVsVHMRIqhAH6w\",\"entity\":\"payment\",\"amount\":1000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVsVHOiRCPgK2J\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":20,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693310791}}', '2023-08-29 06:36:50', '2023-08-29 06:36:50'),
(4, 'pay_MVslLJdpmz1exe', 0, 'card', 'INR', 'void@razorpay.com', '', '5', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVslLJdpmz1exe\",\"entity\":\"payment\",\"amount\":500,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVslLLRbC99Xym\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":10,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693311704}}', '2023-08-29 06:52:03', '2023-08-29 06:52:03'),
(5, 'pay_MVsx3CC995eWsL', 0, 'card', 'INR', 'void@razorpay.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVsx3CC995eWsL\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVsx3DsD2sv3bu\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693312369}}', '2023-08-29 07:03:06', '2023-08-29 07:03:06'),
(6, 'pay_MVszdLxqwRn8Xz', 0, 'card', 'INR', 'void@razorpay.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVszdLxqwRn8Xz\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVszdNuQm1tmKk\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693312515}}', '2023-08-29 07:05:33', '2023-08-29 07:05:33'),
(7, 'pay_MVt4314S8F0Lqm', 0, 'card', 'INR', 'void@razorpay.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVt4314S8F0Lqm\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVt433dKnDjfP5\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693312766}}', '2023-08-29 07:09:42', '2023-08-29 07:09:42'),
(8, 'pay_MVtA0rfO8Kivai', 0, 'card', 'INR', 'void@razorpay.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MVtA0rfO8Kivai\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MVtA0tTHmTA8Ax\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693313105}}', '2023-08-29 07:15:21', '2023-08-29 07:15:21'),
(9, 'pay_MWeL9GETVeKjOo', 0, 'card', 'INR', 'void@razorpay.com', '', '50000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWeL9GETVeKjOo\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWeL9IaZNw5aLc\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693479253}}', '2023-08-31 05:24:31', '2023-08-31 05:24:31'),
(10, 'pay_MWeN76FENagjcn', 0, 'card', 'INR', 'void@razorpay.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWeN76FENagjcn\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWeN78IzBWFeG6\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693479365}}', '2023-08-31 05:26:22', '2023-08-31 05:26:22'),
(11, 'pay_MWeOm9VpRLjDim', 0, 'card', 'INR', 'void@razorpay.com', '', '1000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWeOm9VpRLjDim\",\"entity\":\"payment\",\"amount\":100000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWeOmBD2CZhk9Z\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":2000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693479459}}', '2023-08-31 05:28:01', '2023-08-31 05:28:01'),
(12, 'pay_MWeV5RlL4vtG0z', 0, 'card', 'INR', 'void@razorpay.com', '', '1000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWeV5RlL4vtG0z\",\"entity\":\"payment\",\"amount\":100000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWeV5URSz9h6Vr\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":2000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693479818}}', '2023-08-31 05:33:57', '2023-08-31 05:33:57'),
(13, 'pay_MWeZQNtdPhqoAQ', 44, 'card', 'INR', 'user@gmail.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWeZQNtdPhqoAQ\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWeZQQjtnqCA2r\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"user@gmail.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693480064}}', '2023-08-31 05:38:02', '2023-08-31 05:38:02'),
(14, 'pay_MWebzfIUlc5CVx', 43, 'card', 'INR', 'rudrrana@gmailcom', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWebzfIUlc5CVx\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWebzi7BZrew7B\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693480210}}', '2023-08-31 05:40:29', '2023-08-31 05:40:29'),
(15, 'pay_MWgkxoLS7BfXal', 14, 'card', 'INR', 'consultant@gmail.com', '', '1000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWgkxoLS7BfXal\",\"entity\":\"payment\",\"amount\":100000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWgkxqq3qhffSx\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":2000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693487763}}', '2023-08-31 07:46:21', '2023-08-31 07:46:21'),
(16, 'pay_MWgng3S9sgJoJl', 14, 'card', 'INR', 'consultant@gmail.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWgng3S9sgJoJl\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MWgng7BbwgePtK\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919808666701\",\"notes\":{},\"fee\":1000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693487917}}', '2023-08-31 07:48:54', '2023-08-31 07:48:54'),
(17, 'pay_MWx4erc2MVbQNU', 14, 'netbanking', 'INR', 'consultant@gmail.com', '', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MWx4erc2MVbQNU\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":null,\"bank\":\"BARB_R\",\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1180,\"tax\":180,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693545227}}', '2023-08-31 23:44:03', '2023-08-31 23:44:03'),
(18, 'pay_MX2Na7HttfzsuC', 44, 'netbanking', 'INR', 'user@gmail.com', 'Silver', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MX2Na7HttfzsuC\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":null,\"bank\":\"BARB_R\",\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1180,\"tax\":180,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693563910}}', '2023-09-01 04:55:25', '2023-09-01 04:55:25'),
(19, 'pay_MX2etCIGMHVR4t', 44, 'netbanking', 'INR', 'user@gmail.com', 'Silver', '500', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MX2etCIGMHVR4t\",\"entity\":\"payment\",\"amount\":50000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":null,\"bank\":\"BARB_R\",\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":1180,\"tax\":180,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693564893}}', '2023-09-01 05:11:48', '2023-09-01 05:11:48'),
(20, 'pay_MX2fUUtStAcUZl', 44, 'netbanking', 'INR', 'user@gmail.com', 'Gold', '1000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MX2fUUtStAcUZl\",\"entity\":\"payment\",\"amount\":100000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":null,\"bank\":\"BARB_R\",\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":2360,\"tax\":360,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693564927}}', '2023-09-01 05:12:22', '2023-09-01 05:12:22'),
(21, 'pay_MX2j5pu7AREru3', 14, 'card', 'INR', 'consultant@gmail.com', 'Gold', '1000', '{\"\\u0000*\\u0000attributes\":{\"id\":\"pay_MX2j5pu7AREru3\",\"entity\":\"payment\",\"amount\":100000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":null,\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Rozerpay\",\"card_id\":\"card_MX2j5t6jT1roWG\",\"card\":{},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"void@razorpay.com\",\"contact\":\"+919408666701\",\"notes\":{},\"fee\":2000,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{},\"created_at\":1693565132}}', '2023-09-01 05:15:49', '2023-09-01 05:15:49'),
(22, '12', 44, NULL, NULL, NULL, 'Silver', '500', NULL, '2023-09-01 05:31:05', '2023-09-01 05:31:05'),
(23, '12', 44, NULL, NULL, NULL, 'Silver', '500', NULL, '2023-09-01 05:33:10', '2023-09-01 05:33:10');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'role-list', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(2, 'role-create', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(3, 'role-edit', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(4, 'role-delete', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(5, 'product-list', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(6, 'product-create', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(7, 'product-edit', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38'),
(8, 'product-delete', 'web', '2023-07-21 00:42:38', '2023-07-21 00:42:38');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `about` varchar(255) DEFAULT NULL,
  `contactNo2` varchar(255) DEFAULT NULL,
  `skypeId` varchar(255) DEFAULT NULL,
  `webSite` varchar(255) DEFAULT NULL,
  `map` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `company` longtext DEFAULT NULL,
  `categoryId` varchar(255) DEFAULT NULL,
  `packageId` varchar(255) DEFAULT NULL,
  `isFeatured` varchar(255) NOT NULL DEFAULT 'No',
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `userId`, `about`, `contactNo2`, `skypeId`, `webSite`, `map`, `address`, `state`, `city`, `pincode`, `photo`, `type`, `company`, `categoryId`, `packageId`, `isFeatured`, `status`, `created_at`, `updated_at`) VALUES
(1, 10, 'Laravel Devloper', '8596589658', '123456789', 'SMVS', 'http://127.0.0.1:8000/profile-update/10', 'surendranagar', '1', '1', '363030', '1690261667.jpg', NULL, 'Silver Oak', '1', '1', 'No', 'Active', '2023-07-22 01:01:34', '2023-07-24 23:37:47'),
(2, 1, '<p>Laravel Devloper</p>', '9865321478', '89562dssdsd5sdsadsd784', 'consultantcube', 'SURENDRANAGAR', '<p>surendrnagar</p>', '1', '1', '363030', '1690370675.jpg', NULL, 'Silver Wings', '3', '1', 'No', 'Active', '2023-07-22 01:03:48', '2023-08-02 01:40:03'),
(3, 2, '<p>Laravel Devloper</p>', '2356897412', '123456dfdfd78', 'consultantcube', 'SURENDRANAGAR', '<p>Ganp[ati fatsar</p>', '1', '1', '363030', '1690960131.jpg', NULL, 'TCS', '5', '1', 'No', 'Active', '2023-07-22 01:38:31', '2023-08-02 01:39:17'),
(5, 14, 'Laravel Devloper', NULL, NULL, 'http://127.0.0.1:8000/', 'cbnxjvbxbvxvxv', 'Address', 'Select State', NULL, NULL, '1693227708.jpg', NULL, 'Tapovan softech', '5', '1', 'No', 'Active', '2023-07-25 01:38:22', '2023-09-05 00:03:49'),
(20, 33, '<p>Web Developer Of Java</p>', '8596589658', '123456789', 'http://127.0.0.1:8000/', 'location ahemdabad', '<p>Ahemdabad</p>', 'Select State', '12', '85001', '1691989284.jpg', 'consultant', 'Test softech', '5', '2', 'No', 'Active', '2023-08-08 05:22:21', '2023-08-14 00:03:39'),
(22, 37, '<p>Trader</p>', '8596589658', '123456789', 'http://127.0.0.1:8000/', 'aaaa', 'Ahemdabad', '1', '33', '360001', '1692017497.jpg', 'consultant', 'Times Softech', '8', '1', 'No', 'Active', '2023-08-14 01:45:03', '2023-08-14 07:21:37'),
(23, 39, '<p>AAAA</p>', '7383389182', '123456789', 'http://127.0.0.1:8000/', 'aaaaaaaa', '<p>Ahemdabad</p>', '1', '33', NULL, '1690370675.jpg', 'consultant', 'Fabric Center', '8', '1', 'No', 'Active', '2023-08-14 03:28:46', '2023-08-14 03:28:46'),
(24, 40, NULL, NULL, NULL, 'xcvbnmklsdfghjk', NULL, '<p>Addressssssssssssss</p>', 'Select State', NULL, NULL, '1693473223.jpg', 'consultant', 'Hey Hello', '6', '2', 'No', 'Active', '2023-08-31 03:38:49', '2023-08-31 04:00:30'),
(25, 41, NULL, '986521478', NULL, NULL, NULL, NULL, '1', '30', NULL, NULL, 'consultant', 'Om Obroy', '6', '2', 'No', 'Active', '2023-08-31 04:47:58', '2023-08-31 04:47:58'),
(26, 43, NULL, NULL, NULL, NULL, NULL, NULL, 'Select State', NULL, NULL, '1693480271.jpg', 'User', NULL, NULL, NULL, 'No', 'Active', '2023-08-31 05:06:57', '2023-08-31 05:41:11'),
(27, 44, NULL, '8523697412', NULL, NULL, NULL, NULL, '1', '33', NULL, NULL, 'User', NULL, NULL, NULL, 'No', 'Active', '2023-08-31 05:20:47', '2023-08-31 05:20:47');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'web', '2023-07-20 04:30:17', '2023-07-21 00:43:38'),
(2, 'Consultant', 'web', '2023-07-21 00:39:22', '2023-07-21 00:39:22'),
(3, 'User', 'web', '2023-07-21 00:39:22', '2023-07-21 00:39:22');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `photo`, `type`, `status`, `created_at`, `updated_at`) VALUES
(1, '1692966097.webp', 'Home', 'Active', '2023-08-25 06:51:37', '2023-08-25 06:51:37'),
(2, '1692966115.jpg', 'Home', 'Deleted', '2023-08-25 06:51:55', '2023-08-25 07:28:07'),
(3, '1692966158.jpg', 'Home', 'Active', '2023-08-25 06:52:38', '2023-08-25 06:52:38'),
(4, '1692968091.jpg', 'Inner', 'Active', '2023-08-25 06:52:59', '2023-08-25 07:24:51'),
(5, '1692966268.jpg', 'Home', 'Active', '2023-08-25 06:54:28', '2023-08-25 07:55:38'),
(6, '1692967914.webp', 'Home', 'Active', '2023-08-25 06:55:15', '2023-08-25 07:24:03'),
(7, '1692969496.jpg', 'Home', 'Active', '2023-08-25 07:48:16', '2023-08-25 07:48:16'),
(8, '1693806979.webp', 'Inner', 'Active', '2023-09-04 00:26:19', '2023-09-04 00:26:19'),
(9, '1693806993.jpg', 'Inner', 'Active', '2023-09-04 00:26:33', '2023-09-04 00:26:33'),
(10, '1693807017.webp', 'Inner', 'Active', '2023-09-04 00:26:57', '2023-09-04 00:26:57');

-- --------------------------------------------------------

--
-- Table structure for table `social_links`
--

CREATE TABLE `social_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `socialMediaMasterId` int(11) NOT NULL,
  `url` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_links`
--

INSERT INTO `social_links` (`id`, `userId`, `socialMediaMasterId`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 1, 'http://127.0.0.1:8000/socialLink-edit/1', 'Deleted', '2023-07-21 04:51:58', '2023-07-26 06:05:36'),
(2, 10, 3, 'www.instagram.com log in', 'Deleted', '2023-07-21 05:04:14', '2023-07-24 23:33:56'),
(3, 14, 3, 'https://www.youtube.com/watch?v=BBAyRBTfsOU&list=RDBBAyRBTfsOU&start_radio=1', 'Deleted', '2023-07-22 01:41:53', '2023-07-25 07:37:33'),
(4, 14, 3, 'http://127.0.0.1:8000/socialLink-create', 'Deleted', '2023-07-25 06:52:29', '2023-07-25 07:37:51'),
(5, 14, 2, 'http://127.0.0.1:8000/socialLink-create', 'Deleted', '2023-07-25 06:52:45', '2023-07-26 05:23:59'),
(6, 14, 3, 'http://127.0.0.1:8000/socialLink-create', 'Deleted', '2023-07-26 01:53:20', '2023-07-26 05:22:42');

-- --------------------------------------------------------

--
-- Table structure for table `social_masters`
--

CREATE TABLE `social_masters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_masters`
--

INSERT INTO `social_masters` (`id`, `title`, `logo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Amazon', '1689932843.png', 'Deleted', '2023-07-21 04:17:24', '2023-07-24 06:17:59'),
(2, 'Facebook', '1690182345.png', 'Active', '2023-07-21 04:28:34', '2023-07-24 01:35:46'),
(3, 'Instagram', '1690182363.avif', 'Active', '2023-07-24 01:36:03', '2023-07-24 01:36:03'),
(4, 'Twitter', '1690182376.png', 'Active', '2023-07-24 01:36:16', '2023-07-24 01:36:16'),
(5, 'You Tube', '1692772151.jpg', 'Active', '2023-07-25 06:27:11', '2023-08-23 00:59:12');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stateName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `stateName`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Gujrat', 'Active', '2023-08-11 06:55:12', '2023-08-11 06:55:12');

-- --------------------------------------------------------

--
-- Table structure for table `times`
--

CREATE TABLE `times` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `times`
--

INSERT INTO `times` (`id`, `day`, `time`, `userId`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Sunday', '12:53', 14, 'Active', '2023-07-29 01:53:29', '2023-07-29 03:04:10'),
(2, 'Monday', '14:57', 14, 'Active', '2023-07-29 02:57:40', '2023-07-29 02:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `stateId` int(11) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `contactNo` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `planType` varchar(255) NOT NULL DEFAULT 'Free',
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `lastName`, `email_verified_at`, `password`, `stateId`, `cityId`, `contactNo`, `gender`, `birthdate`, `planType`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', 'Admin', '0000-00-00 00:00:00', '$2y$10$abD.DOz/DGsF7qZlQy75vO2HheYxNkAQRo3P9w6bpB3qGbv3fCyAu', NULL, NULL, NULL, NULL, NULL, 'Silver', 'Active', NULL, '2023-07-20 04:30:17', '2023-08-26 00:20:06'),
(2, 'Manisha', 'manisha@gmail.com', 'Parmar', NULL, '$2y$10$ql4HaplDiptFKL3/1lJi1uKwgVWqR7MA8S7dSIu1/BxW9IMcrIr2q', 1, 1, '8956321478', 'Female', '1997-05-03', 'free', 'Active', NULL, '2023-07-21 07:42:39', '2023-07-21 22:59:05'),
(14, 'Consultant', 'consultant@gmail.com', 'Cube', NULL, '$2y$10$dIMGQV/upqepOLkKSBYpWegjOVnd/h4Vs8o5Noe0zhylodA2O5csq', 1, 1, '9865324178', 'Female', '1997-03-30', 'Silver', 'Active', NULL, '2023-07-25 01:38:22', '2023-08-25 06:01:40'),
(33, 'Lata', 'lata@gmail.com', 'Jadav', NULL, '$2y$10$MNpK3qZYWClKCLMJ9UN8j.Rn8CPj0RArPaS5N09BjVbR.4X0zz2bi', 1, 1, '9785416325', 'Male', '2023-08-06', 'free', 'Active', NULL, '2023-08-08 05:22:21', '2023-08-14 00:51:31'),
(37, 'Bhavin', 'bhavin@gmail.com', 'Vaghela', NULL, '$2y$10$etZDlR8qHnQdTXn2C1AKQOHMHdB1rce0GuHH/JDr5.HzoYTTOvAlW', 1, 1, '8347734731', 'Male', '1995-05-17', 'free', 'Active', NULL, '2023-08-14 01:45:03', '2023-08-14 01:45:03'),
(39, 'Rahul', 'rahul@gmail.com', 'Parmar', NULL, '$2y$10$hYKmEpZIgl0sdiZnzcmbCOXtsVzj2btvB55hqCk5A1GlPna7aqmHW', 1, 33, '7383389182', 'Male', '1995-07-18', 'free', 'Active', NULL, '2023-08-14 03:28:46', '2023-08-14 03:28:46'),
(40, 'Hey Hello', 'hey@gmail.com', 'Hello', NULL, '$2y$10$bIFJUcsP/X/dlKd6/ZCJZeEyRYIhHFGTZ1EJTFaIMbCG8dyEVcFeW', 1, 1, '8596321478', 'Female', '2023-08-31', 'Free', 'Active', NULL, '2023-08-31 03:38:49', '2023-08-31 03:54:46'),
(41, 'Sivay', 'sivay@gmail.com', 'Obraoy', NULL, '$2y$10$o0dckQBcEQVAPKTQ8mMZkeRXeJhyM2mM4sGMOGaK20EYe8IyH6YIS', 1, 30, '986521478', 'Male', '2023-09-01', 'Free', 'Active', NULL, '2023-08-31 04:47:58', '2023-08-31 04:47:58'),
(43, 'Rudr', 'rudrrana@gmailcom', 'Rana', NULL, '$2y$10$LssPJF8a2ArBgu6Tr.w1muYIichLsI1f5Hokxkss1CDR6ypO0g/bu', 1, 1, '7845123698', 'Male', '2023-09-01', 'Free', 'Active', NULL, '2023-08-31 05:06:57', '2023-08-31 05:06:57'),
(44, 'User', 'user@gmail.com', 'User', NULL, '$2y$10$1X1N8tfnR.Sz1OVvDbj3rOQojNOQI1k2iFuHEXn.yIgzUOY7GBU3K', 1, 33, '8523697412', 'Male', '2023-08-31', 'Free', 'Active', NULL, '2023-08-31 05:20:47', '2023-08-31 05:20:47');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `userId`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'http://127.0.0.1:8000/video-edit/2', 'Deleted', '2023-07-21 06:38:24', '2023-07-27 00:56:54'),
(2, 14, 'http://127.0.0.1:8000/video-create/3333', 'Deleted', '2023-07-21 06:43:09', '2023-07-25 07:34:11'),
(3, 14, 'http://127.0.0.1:8000/video', 'Active', '2023-07-25 06:37:19', '2023-07-26 04:10:29'),
(4, 14, 'http://127.0.0.1:8000/video-edit', 'Deleted', '2023-07-25 06:37:42', '2023-07-27 01:07:42'),
(5, 14, 'http://127.0.0.1:8000/video-index', 'Deleted', '2023-07-25 06:38:08', '2023-07-27 00:57:30'),
(6, 14, 'http://127.0.0.1:8000/video-store', 'Deleted', '2023-07-25 06:38:38', '2023-07-25 07:35:33'),
(7, 14, 'http://127.0.0.1:8000/video-create', 'Deleted', '2023-07-26 01:40:42', '2023-07-26 06:08:16'),
(8, 14, 'http://127.0.0.1:8000/video-edit/8', 'Deleted', '2023-07-26 01:41:12', '2023-07-26 06:08:10'),
(9, 14, 'fghgggfhgfhgfhgh', 'Deleted', '2023-07-26 01:41:34', '2023-07-26 05:20:32'),
(10, 14, 'http://127.0.0.1:8000/video-edit/10', 'Deleted', '2023-07-26 06:26:39', '2023-07-27 00:51:22'),
(11, 14, 'https://www.youtube.com/watch?v=2CXSw1oPj3I&list=RDChyR-8YNPMA&index=4', 'Active', '2023-07-27 01:08:12', '2023-07-29 04:35:38'),
(12, 14, 'https://www.youtube.com/watch?v=ktPD6TMovxs&list=RDChyR-8YNPMA&index=2', 'Active', '2023-07-28 05:27:57', '2023-07-29 04:35:16'),
(13, 14, 'http://127.0.0.1:8000/video-create', 'Active', '2023-07-29 02:35:52', '2023-07-29 02:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `workshops`
--

CREATE TABLE `workshops` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `workshopType` varchar(255) NOT NULL,
  `link` longtext DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `workshopDate` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workshops`
--

INSERT INTO `workshops` (`id`, `userId`, `title`, `price`, `detail`, `workshopType`, `link`, `address`, `workshopDate`, `status`, `created_at`, `updated_at`) VALUES
(1, 14, 'aaa', '1000', '<p>aaa</p>', 'Online', 'https://kothiyahospital.com/', '', '2023-08-24', 'Active', '2023-08-24 05:26:00', '2023-08-24 07:12:49'),
(2, 15, 'bbb', '10000', 'bbb', 'Offline', '', 'aaaaaaa', '2023-08-24', 'Deleted', '2023-08-24 05:26:49', '2023-08-24 06:47:31'),
(3, 14, 'qqq', '1000', 'qqq', 'Offline', '', 'aaaaaaaaa', '2023-08-24', 'Deleted', '2023-08-24 06:59:28', '2023-08-24 07:00:03'),
(4, 13, 'wwww', '1000', 'www', 'Online', 'http://127.0.0.1:8000/api/workshop/update/4', '', '25/08/2023', 'Deleted', '2023-08-24 07:09:13', '2023-08-24 07:46:14'),
(5, 14, 'gg', '500', '<p>gg</p>', 'Offline', '', 'aaaaaaaaaaaaa', '2023-08-25', 'Active', '2023-08-24 07:34:42', '2023-08-25 01:03:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_packages`
--
ALTER TABLE `admin_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactuses`
--
ALTER TABLE `contactuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `language_masters`
--
ALTER TABLE `language_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_masters`
--
ALTER TABLE `social_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `times`
--
ALTER TABLE `times`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workshops`
--
ALTER TABLE `workshops`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `admin_packages`
--
ALTER TABLE `admin_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `contactuses`
--
ALTER TABLE `contactuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `language_masters`
--
ALTER TABLE `language_masters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `social_masters`
--
ALTER TABLE `social_masters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `times`
--
ALTER TABLE `times`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `workshops`
--
ALTER TABLE `workshops`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
