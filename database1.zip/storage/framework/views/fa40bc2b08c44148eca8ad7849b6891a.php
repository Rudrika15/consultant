

<?php $__env->startSection('header','Workshop'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>



<div class="card">
    <!-- /.box-title -->
    <div class="card-header" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #345BCB; color:white;">

        <div class="">
            <h4 class="">Update Workshop</h4>
        </div>
        <div class="">
            <a href="<?php echo e(route('workshop.index')); ?>" class="btn btnback btn-sm">BACK</a>

            <!-- /.sub-menu -->
        </div>
    </div>
    <!-- /.dropdown js__dropdown -->

    <div class="card-body">
        <form class="form-group" id="workshopForm" name="workshopForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="workshopId" id="workshopId" value=<?php echo e($workshop->id); ?>>
            <div class="form-label-group mt-3">
                <label for="title" class="fw-bold">Title <sup class="text-danger">*</sup></label>
                <input id="title" type="text" name="title" value="<?php echo e($workshop->title); ?>" class="form-control" placeholder="Title">
                <?php if($errors->has('title')): ?>
                <span class="error"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="price" class="fw-bold">Price <sup class="text-danger">*</sup></label>
                <input id="price" type="text" name="price" value="<?php echo e($workshop->price); ?>" class="form-control" placeholder="Price">
                <?php if($errors->has('price')): ?>
                <span class="error"><?php echo e($errors->first('price')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">
                <label for="detail" class="fw-bold">Detail <sup class="text-danger">*</sup></label>
                <textarea id="detail" rows="10" name="detail" class="form-control"><?php echo e($workshop->detail); ?></textarea>
                <?php if($errors->has('detail')): ?>
                <span class="error"><?php echo e($errors->first('Detail')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-label-group mt-3">                
                <label for="price" class="fw-bold">Workshop Type <sup class="text-danger">*</sup></label>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-check ">
                            <input class="form-check-input" type="radio" name="workshopType" id="Online" value="Online" <?php echo e($workshop->workshopType === 'Online' ? 'checked' : ''); ?>> 
                            <label class="form-check-label" for="flexRadioDefault1">
                                <?php echo e(__('Online')); ?>

                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="workshopType" id="Offline" value="Offline" <?php echo e($workshop->workshopType === 'Offline' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="flexRadioDefault2">
                                <?php echo e(__('Offline')); ?>

                            </label>
                        </div>
                    </div>
                    <?php if($errors->has('workshopType')): ?>
                    <span class="error"><?php echo e($errors->first('workshopType')); ?></span>
                    <?php endif; ?>
                    
                </div>
            </div>
            
            <div class="form-label-group mt-3" id="link" style="display:none;">
                <label for="link" class="fw-bold">Link</label>
                <input id="link" type="text" name="link" value="<?php echo e($workshop->link); ?>" class="form-control" placeholder="link">
               
            </div>
            <div class="form-label-group mt-3" id="address"  style="display:none;">
                <label for="address" class="fw-bold">Address </label>
                <input id="address" type="text" name="address" value="<?php echo e($workshop->address); ?>" class="form-control" placeholder="address">
                
            </div>
            <div class="form-label-group mt-3">
                <label for="workshopDate" class="fw-bold">Workshop Date <sup class="text-danger">*</sup></label>
                <input id="workshopDate" type="date" name="workshopDate" value="<?php echo e($workshop->workshopDate); ?>" class="form-control" placeholder="workshopDate">
                <?php if($errors->has('workshopDate')): ?>
                <span class="error"><?php echo e($errors->first('workshopDate')); ?></span>
                <?php endif; ?>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mt-5 text-center">
                <button type="submit" id="saveBtn" class="btn btn-primary">Submit</button>
            </div>

        </form>

        <!-- </div> -->
    </div>

    <!-- Collapsable Card Example -->

</div>
<script src="https://cdn.ckeditor.com/ckeditor5/38.1.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#detail'))
            .then(editor => {
                // console.log(inquiry );
            })
            .catch(error => {
                console.error(error);
            });
    </script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
    $(document).ready(function(){
    $("#Online").click(function(){
        $("#link").show();
        $("#address").hide();
    });
    $("#Offline").click(function(){
        $("#address").show();
        $("#link").hide();
    });
    });
</script>

<script type="text/javascript">
    $(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
       
        $('#workshopForm').submit(function(e) {
        e.preventDefault();
        let formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('workshop.update')); ?>",
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    // Success message using SweetAlert
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response.message,
                    }, 200);
                    
                } else {
                    // Error message using SweetAlert
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred!',
                    });
                }
            },
            error: function(xhr, status, error) {
                // Error message using SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred!',
                });
            }
        });
    });
       
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/consultant/workshop/edit.blade.php ENDPATH**/ ?>