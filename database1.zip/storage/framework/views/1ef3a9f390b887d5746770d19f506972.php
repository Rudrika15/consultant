
<?php $__env->startSection('content'); ?>
    <div class="main_page">
        <h1>Sign up Package</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.visitorApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\consultant\consultant\resources\views/visitors/signuppackage.blade.php ENDPATH**/ ?>