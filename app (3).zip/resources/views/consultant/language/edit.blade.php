@extends('layouts.app')

@section('header','Language')
@section('content')

{{-- Message --}}
@if (Session::has('success'))
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> {{ session('success') }}
</div>
@endif

@if (Session::has('error'))
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> {{ session('error') }}
</div>
@endif



<div class="card">
    <!-- /.box-title -->
    <div class="card-header"
        style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #345BCB; color:white;">

        <div class="">
            <h4 class="">Create Language</h4>
        </div>
        <div class="">
            <a href="{{ route('language.index') }}" class="btn btn-info btn-sm">BACK</a>

            <!-- /.sub-menu -->
        </div>
    </div>
    <!-- /.dropdown js__dropdown -->

    <div class="card-body">
        <form class="form-group" id="languageForm" name="languageForm" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="id" id="id" value="{{$language->id}}">
            <div class="form-label-group mt-3">
                <div class="form-group">
                    <strong>Language Master Name:</strong>
                    <select class="form-control" data-error='State Name Field is required' required name="languageId"
                        id="languageId">
                        <option value="" selected disabled> Select Language Master </option>
                        @foreach ($languageMaster as $languageMasterData)
                        <option value="{{ $languageMasterData->id }}" {{$languageMasterData->id ==
                            old('languageId',$language->languageId)? 'selected':''}}>{{ $languageMasterData->language }}
                        </option>
                        @endforeach
                    </select>
                    <div class="help-block with-errors"></div>
                    @error('languageId')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 mt-5 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>

        </form>
        <!-- </div> -->
    </div>
    <!-- Collapsable Card Example -->

</div>
<script type="text/javascript">
    $(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready(function() {
            // Get the values you want to update
            $("#languageForm").submit(function(event) {
                event.preventDefault();
                var id = $('#id').val();
                var languageId = $('#languageId').val();

                $.ajax({
                    url: "{{route('language.update')}}",
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}', // Include the CSRF token for Laravel security
                        id: id,
                        languageId: languageId,
                    },
                    success: function(response) {
                        if (response.success) {
                        // Success message using SweetAlert
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                        },200);
                    } else {
                        // Error message using SweetAlert
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'An error occurred!',
                        });
                    }
                    },
                    error: function(xhr, status, error) {
                    // Error message using SweetAlert
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'An error occurred!',
                        });
                    }
                });
            });
        });
    });
</script>
@endsection